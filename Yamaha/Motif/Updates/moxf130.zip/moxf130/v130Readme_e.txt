============ MOTIF XF6/MOTIF XF7/MOTIF XF8 V1.30 Operating System Updater Readme ============

Thank you for purchasing the Yamaha MOTIF XF Series, Music Production Synthesizer.
This Readme file contains important information about the MOTIF XF6/MOTIF XF7/MOTIF XF8 V1.30 Operating System update and the updating process. Please read this document carefully before updating your MOTIF XF synthesizer.


Caution:
- This updater is only for the MOTIF XF synthesizer.
- This updater is to be used at the user's own risk.
- All User data (User Voices, User Performances, Songs and so on) will be initialized by this updater. Please make sure that you save all User data to a USB storage device or to a computer connected to the same network before performing this update. 
- The unit may become inoperable if the electrical supply is interrupted while running the updater (by pulling out the AC cord, etc.). If this happens, run the updater again from the first step. 
- If the unit does not function after running the updater, please contact your nearest Yamaha service center.
Yamaha Global Gateway
http://www.global.yamaha.com/countries/index.html


This update is applicable to the following models: 
MOTIF XF6/MOTIF XF7/MOTIF XF8 with firmware versions earlier than 1.30


How to check the version of your MOTIF XF
1. Push [UTILITY] to enter the Utility mode.
2. Push [UTILITY], [Cursor Up] and [F1] buttons simultaneously. 
The following message will appear:

        -------------------------------------
        About MOTIF XF
          Current Version
             MOTIF XF Firmware Version *.**.*
             MOTIF XF Kernel Version ************
             MOTIF XF Contents Version *.**.*
        -------------------------------------
The unit's version is indicated by " MOTIF XF Firmware Version *.**.* "
Only the numbers up to the two decimal places after the first dot are important in reading the version number, you can ignore the numbers after the second dot. 
Ex.) 1.01.0 =1.01 ,  1.12.0= 1.12
Press the [EXIT] button to exit version information.


Updating Procedure
- All User data (User Voices, User Performances, Songs and so on) will be initialized by this updater when you are updating from V1.12 or an earlier version. Please make sure that you save all User data to a USB storage device or to a computer connected to the same network before performing this update. 
When you need to backup the data written in Flash Memory Expansion Module, set the Type to "All" and select "without sample" in Save FL1, Save FL2 in the File mode.
==
Save FL1: without sample 
Save FL2: without sample
==
Moreover, when you load backup data, make the following settings.
�yIn File Mode�z
Type -> All 
Load USR -> USR
Load FL1 -> FL1 without sample
Load FL2 -> FL2 without sample 

After you've completed the update and reboot the MOTIF XF, the message "New Flash Memory Module, Please load waveform data" will be displayed. Load the backup data (the message disappears).

-----------------
Required Items
- One USB memory device of over 512MB capacity formatted on the MOTIF XF

1. After downloading, copy the uncompressed [8K44OS_.PGM] file to a USB memory device that has been formatted on the MOTIF XF. No other files should be present on the USB memory device.

2. Power off the MOTIF XF.

3. Connect the USB memory device copied in step 1 into the MOTIF XF. Power on the MOTIF XF while holding down the [Cursor UP] button and [UTILITY] buttons until the "MOTIF XF" logo appears on screen.

4. The MOTIF XF OS updater will begin with the message "Searching for the firmware updater," indicating "......%". 
When the message "Finish. Please turn off " appears, turn off the MOTIF XF and remove the USB memory device.

NOTICE: 
The update process takes from several to five minutes (It may change with conditions.). DO NOT power off or remove the USB device from the MOTIF XF during this time. If the electrical supply is accidently interrupted while running the updater (by pulling out the AC cord, etc.), the unit may become inoperable. If this happens, run the updater again. If the unit does not function after doing this, please contact your nearest Yamaha service center.

5. Press the [UTILITY], [Cursor Up] and [F1] buttons simultaneously to check the firmware version to confirm that the unit has been successfully updated. 

This concludes the update process.


Main Fixes and Enhancements
<V1.20 to V1.30>
New features;
- Now MOTIF XF can download the latest information about the instrument from a special Yamaha server and show it on the display.

- Now you can change the playback speed of the Audio Playback in File mode without changing the pitch. Also, you can start Audio Playback from any desired point in the audio data.

- Now you can select Pro Tools in the Remote DAW type.

- Network function now supports Mac OS X 10.7 .

- Now supports iPad application Cloud Audio Recorder for MOTIF XF.

Solved problems;
- Fixed a problem in which some Voice parameters might not be applied to the tone generator correctly in the Song, Pattern or Performance mode when the Arpeggio Type was changed for a Voice with ARP = "on."

- Fixed a problem in which the information on the display and the status of the tone generator would be different with each other when Factory Set was executed without "All" being checkmarked while the instrument and the MOTIF XF editor were online.

- Fixed a problem in which the "05: Create Continuous Data" job would be applied with the before-edited value of the Data Range, even though you edited the value with a USB ASCII keyboard.

- Fixed a problem in which exectuting Set/Clear of the Favorite via [ENTER]+[CATEGOTY SEARCH] while the instrument and the MOTIF XF editor were online would not affect the editor.

- Fixed a problem in which the MOTIF XF editor might remain locked even though the instrument was exited from the Other Job "05: Delete Same Name Waveforms" display of the Sampling mode.

- Fixed a problem in which the used by Voice information shown in the Flash display of Utility would not be updated when the MOTIF XF editor was synchronized with the instrument.

- Fixed a problem in which the Edit Indicator would remain even though the Mixing data was stored via the MOTIF XF editor.

- Fixed a problem in which the Sample Voices and the Mixing Voices in the Song or Pattern data could not be called up after the Song or Pattern data were stored to another number.

- Execution time for Clear All of the Category Search has been reduced.

- Execution time for Format and Delete All on the Flash display in Utility has been reduced.

- Fixed a problem in which Note On events might sound when inserting events filtered by View Filter on the edit display of the Song or Pattern mode.

- Fixed a problem in which the specified range would not be deleted correctly via the 02: Delete Measure Job after the 01: Create Measure Job is executed in the Song mode. 

- Improved the Ribbon Controller Sensitivity when you press it quickly.

- Fixed a problem in which the Bank Select and Program Change MIDI messages would not be transmitted in the Voice or Performance mode even if you used the Foot Switch to which the Program Change Inc/Dec was assigned.

- Fixed a problem in which the "01:Copy" of the Keybank Job in the Sampling mode might fail in copying a mono Key Bank.

- Fixed a problem in which the Accent Phrases might not be recorded to the correct timing when Arpeggios including Accent Phrases were recorded to the Song or Pattern.

Other minor problems have been corrected.


<V1.12 to V1.20>
New features;
-Now the MOTIF XF offers Wireless Network functions.

Solved problems;
-Fixed a problem in which this instrument would freeze when receiving a note on message whose velocity is same as the �gHigh�h setting while setting the Velocity Limit parameter of Voice Element Edit so that the �gLow�h setting is one value higher than the �gHigh�h setting; for example, when �gLow�h is set to 65 and �gHigh�h is set to 64.

<V1.00 to V1.12>
New features;
-You can now convert a Sample Voice to a Mixing Voice. 

-You can now edit a Waveform on the optional Flash Memory Expansion Module by using the newly added Sampling Job.

-Normalize, Slice, and Remix have been added to the Sampling Edit display and Sampling Main display respectively, allowing you to more easily call up these displays.

-You can now increase the available memory of the Flash Memory Expansion Module by using the newly added Sampling Job.

-The method of the Key Bank number assignment has been changed from the previous version.

-You can now load WAV or AIFF files in a single folder at the same time. The loaded files will be assigned to the keys in alphabetical order from the specified key.

-You can now load the file without the FL1, FL2 Bank Waveforms, even if the corresponding file contains Waveforms.

-You can now use the Category Search function to find desired Arpeggio Types.

-You can now use the Category Search function to find desired Waveforms.


Solved problems;
-Fixed a problem in which the network-connected computer sometimes might fail to be shown in the Host field of the Mount display in the File mode. 

-Fixed a problem in which it would take a long time to transfer many small size files, such as display templates, to the shared folder of MOTIF XF from a Windows Vista computer.

-Fixed a problem in which an error message would not appear even though you attempted to save a WAV or AIFF file with a size exceeding maximum capacity to the shared folder of a network-connected computer from the MOTIF XF.

-Fixed a problem in which some MIDI events that should be erased by the Slice operation would be maintained.

-Fixed a problem in which re-selecting the destination might call up the old previous Mix Voice name although the Mix Voice Job-Copy was completed in the Voice Edit of the Mixing mode. 

-Fixed a problem in which ARP Sync Quantize might occasionally not work.

-Fixed a problem in which the folder and file list might occasionally not be shown even though a USB memory device is connected.

-Fixed a problem in which the wrong key might be shown on the Slice display of the Sampling Job when you executed then canceled the Slice operation.

-Fixed a problem in which the empty folder of the network-connected Windows computer would fail to be shared from the MOTIF XF with the error message "Disk or memory read/write error." 

-Fixed a problem in which the key would be set to G8 when you entered the File mode from the Performance mode, set the File Type to "wav" or "aiff," set the Key to "all" then exited from and re-entered the File mode. 

-Fixed a problem in which the MOTIF XF would start with the Mode specified at the Power On Mode in the Utility mode and moreover started with the last data before the Factory Set was executed, even though the Power On Auto Factory Set was turned on. 

-Fixed a problem in which the SEQ TRANSPORT buttons would not work when you entered the Sampling mode from Song or Pattern mode, set Recording Type to something other than " sample+note," then started recording.

- Fixed a problem in which the instrument might freeze with "Executing..." displayed when entering the Sampling Edit mode from Voice or Performance mode and then executing and finalizing the Slice operation. 

Other minor problems have been corrected.

======================================================================
The company names and product names in this release note are the trademarks or registered trademarks of their respective companies.
Copyright(c) 2010-2011 Yamaha Corporation. All Rights Reserved.

